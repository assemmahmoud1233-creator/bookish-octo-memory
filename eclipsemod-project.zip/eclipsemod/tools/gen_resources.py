#!/usr/bin/env python3
"""Generates all JSON resources (models, blockstates, recipes, loot, worldgen, lang)."""
import json
import os
import sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "..")
RES = os.path.join(ROOT, "src", "main", "resources")
MOD = "eclipsemod"


def put(rel, data):
    path = os.path.join(RES, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


A = f"assets/{MOD}"
D = f"data/{MOD}"

# ---------- item models ----------
for name in ("eclipse_blade", "eclipse_pickaxe"):
    put(f"{A}/models/item/{name}.json",
        {"parent": "minecraft:item/handheld", "textures": {"layer0": f"{MOD}:item/{name}"}})
for name in ("eclipsium_ingot", "raw_eclipsium"):
    put(f"{A}/models/item/{name}.json",
        {"parent": "minecraft:item/generated", "textures": {"layer0": f"{MOD}:item/{name}"}})
for name in ("eclipsium_ore", "eclipsium_block"):
    put(f"{A}/models/item/{name}.json", {"parent": f"{MOD}:block/{name}"})
    put(f"{A}/models/block/{name}.json",
        {"parent": "minecraft:block/cube_all", "textures": {"all": f"{MOD}:block/{name}"}})
    put(f"{A}/blockstates/{name}.json",
        {"variants": {"": {"model": f"{MOD}:block/{name}"}}})

# ---------- recipes ----------
ING = {"item": f"{MOD}:eclipsium_ingot"}
put(f"{D}/recipes/eclipse_blade.json", {
    "type": "minecraft:crafting_shaped",
    "pattern": ["I", "I", "S"],
    "key": {"I": ING, "S": {"item": "minecraft:stick"}},
    "result": {"item": f"{MOD}:eclipse_blade"}})
put(f"{D}/recipes/eclipse_pickaxe.json", {
    "type": "minecraft:crafting_shaped",
    "pattern": ["III", " S ", " S "],
    "key": {"I": ING, "S": {"item": "minecraft:stick"}},
    "result": {"item": f"{MOD}:eclipse_pickaxe"}})
put(f"{D}/recipes/eclipsium_block.json", {
    "type": "minecraft:crafting_shaped",
    "pattern": ["III", "III", "III"],
    "key": {"I": ING},
    "result": {"item": f"{MOD}:eclipsium_block"}})
put(f"{D}/recipes/eclipsium_ingot_from_block.json", {
    "type": "minecraft:crafting_shapeless",
    "ingredients": [{"item": f"{MOD}:eclipsium_block"}],
    "result": {"item": f"{MOD}:eclipsium_ingot", "count": 9}})
for src, tag, kind, t in (
        ("raw_eclipsium", "raw", "smelting", 200), ("raw_eclipsium", "raw", "blasting", 100),
        ("eclipsium_ore", "ore", "smelting", 200), ("eclipsium_ore", "ore", "blasting", 100)):
    put(f"{D}/recipes/eclipsium_ingot_from_{kind}_{tag}.json", {
        "type": f"minecraft:{kind}",
        "category": "misc",
        "ingredient": {"item": f"{MOD}:{src}"},
        "result": f"{MOD}:eclipsium_ingot",
        "experience": 1.5,
        "cookingtime": t})

# ---------- loot tables ----------
put(f"{D}/loot_tables/blocks/eclipsium_ore.json", {
    "type": "minecraft:block",
    "pools": [{
        "rolls": 1.0, "bonus_rolls": 0.0,
        "entries": [{
            "type": "minecraft:alternatives",
            "children": [
                {"type": "minecraft:item",
                 "conditions": [{"condition": "minecraft:match_tool", "predicate": {
                     "enchantments": [{"enchantment": "minecraft:silk_touch", "levels": {"min": 1}}]}}],
                 "name": f"{MOD}:eclipsium_ore"},
                {"type": "minecraft:item",
                 "functions": [
                     {"function": "minecraft:apply_bonus", "enchantment": "minecraft:fortune",
                      "formula": "minecraft:ore_drops"},
                     {"function": "minecraft:explosion_decay"}],
                 "name": f"{MOD}:raw_eclipsium"}]}]}]})
put(f"{D}/loot_tables/blocks/eclipsium_block.json", {
    "type": "minecraft:block",
    "pools": [{
        "rolls": 1.0, "bonus_rolls": 0.0,
        "conditions": [{"condition": "minecraft:survives_explosion"}],
        "entries": [{"type": "minecraft:item", "name": f"{MOD}:eclipsium_block"}]}]})

# ---------- tags ----------
blocks = [f"{MOD}:eclipsium_ore", f"{MOD}:eclipsium_block"]
put("data/minecraft/tags/blocks/mineable/pickaxe.json", {"replace": False, "values": blocks})
put("data/minecraft/tags/blocks/needs_diamond_tool.json", {"replace": False, "values": blocks})

# ---------- world generation ----------
put(f"{D}/worldgen/configured_feature/eclipsium_ore.json", {
    "type": "minecraft:ore",
    "config": {
        "discard_chance_on_air_exposure": 0.0,
        "size": 6,
        "targets": [
            {"state": {"Name": f"{MOD}:eclipsium_ore"},
             "target": {"predicate_type": "minecraft:tag_match", "tag": "minecraft:stone_ore_replaceables"}},
            {"state": {"Name": f"{MOD}:eclipsium_ore"},
             "target": {"predicate_type": "minecraft:tag_match", "tag": "minecraft:deepslate_ore_replaceables"}}]}})
put(f"{D}/worldgen/placed_feature/eclipsium_ore.json", {
    "feature": f"{MOD}:eclipsium_ore",
    "placement": [
        {"type": "minecraft:count", "count": 3},
        {"type": "minecraft:in_square"},
        {"type": "minecraft:height_range", "height": {
            "type": "minecraft:trapezoid",
            "min_inclusive": {"absolute": -64},
            "max_inclusive": {"absolute": 16}}},
        {"type": "minecraft:biome"}]})
put("data/forge/biome_modifier/add_eclipsium_ore.json", {
    "type": "forge:add_features",
    "biomes": "#minecraft:is_overworld",
    "features": f"{MOD}:eclipsium_ore",
    "step": "underground_ores"})

# ---------- languages ----------
en = {
    "itemGroup.eclipsemod": "Eclipse Arsenal",
    "item.eclipsemod.eclipse_blade": "Eclipse Blade",
    "item.eclipsemod.eclipse_pickaxe": "Eclipse Pickaxe",
    "item.eclipsemod.eclipsium_ingot": "Eclipsium Ingot",
    "item.eclipsemod.raw_eclipsium": "Raw Eclipsium",
    "block.eclipsemod.eclipsium_ore": "Eclipsium Ore",
    "block.eclipsemod.eclipsium_block": "Block of Eclipsium",
    "tooltip.eclipsemod.blade.hit": "Hit: Wither II, Glowing and life-steal",
    "tooltip.eclipsemod.blade.use": "Right Click: Eclipse Dash (4s cooldown)",
    "tooltip.eclipsemod.pickaxe": "Every block mined grants Haste II",
}
ar = {
    "itemGroup.eclipsemod": "ترسانة الكسوف",
    "item.eclipsemod.eclipse_blade": "نصل الكسوف",
    "item.eclipsemod.eclipse_pickaxe": "بيكاكس الكسوف",
    "item.eclipsemod.eclipsium_ingot": "سبيكة الإكليبسيوم",
    "item.eclipsemod.raw_eclipsium": "إكليبسيوم خام",
    "block.eclipsemod.eclipsium_ore": "خام الإكليبسيوم",
    "block.eclipsemod.eclipsium_block": "بلوك الإكليبسيوم",
    "tooltip.eclipsemod.blade.hit": "الضربة: ويذر 2 وتوهج وسرقة حياة",
    "tooltip.eclipsemod.blade.use": "كليك يمين: اندفاعة الكسوف (تبريد 4 ثوانٍ)",
    "tooltip.eclipsemod.pickaxe": "كل بلوك تكسره يمنحك استعجال 2",
}
put(f"{A}/lang/en_us.json", en)
put(f"{A}/lang/ar_sa.json", ar)
print("resources generated")
