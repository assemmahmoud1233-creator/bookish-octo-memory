#!/usr/bin/env python3
"""Procedurally paints all 32x32 textures for Eclipse Arsenal (needs Pillow)."""
import math
import os
import random
import sys

from PIL import Image

ROOT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "..")
ITEM_DIR = os.path.join(ROOT, "src", "main", "resources", "assets", "eclipsemod", "textures", "item")
BLOCK_DIR = os.path.join(ROOT, "src", "main", "resources", "assets", "eclipsemod", "textures", "block")
os.makedirs(ITEM_DIR, exist_ok=True)
os.makedirs(BLOCK_DIR, exist_ok=True)

S = 32
OUTLINE = (12, 5, 30, 255)

# Eclipsium colour ramp: near-black violet -> violet -> bright violet -> cyan -> white
RAMP = [
    (18, 8, 44), (44, 16, 100), (88, 40, 176), (138, 84, 240),
    (110, 190, 255), (150, 245, 255), (255, 255, 255),
]
GOLD = [(60, 38, 14), (120, 80, 24), (200, 150, 50), (250, 215, 110)]
WOOD = [(24, 12, 40), (48, 24, 80), (78, 42, 120), (110, 66, 160)]


def lerp(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def ramp(colors, t):
    t = max(0.0, min(1.0, t))
    f = t * (len(colors) - 1)
    i = min(int(f), len(colors) - 2)
    return lerp(colors[i], colors[i + 1], f - i) + (255,)


def new():
    return Image.new("RGBA", (S, S), (0, 0, 0, 0))


def add_outline(img):
    px = img.load()
    out = img.copy()
    po = out.load()
    for y in range(S):
        for x in range(S):
            if px[x, y][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < S and 0 <= ny < S and px[nx, ny][3] > 0:
                        po[x, y] = OUTLINE
                        break
    return out


def sparkle(img, x, y, color=(255, 255, 255, 255), arm=1):
    px = img.load()
    cx, cy = x, y
    if 0 <= cx < S and 0 <= cy < S:
        px[cx, cy] = color
    for d in range(1, arm + 1):
        for ox, oy in ((d, 0), (-d, 0), (0, d), (0, -d)):
            nx, ny = cx + ox, cy + oy
            if 0 <= nx < S and 0 <= ny < S and px[nx, ny][3] > 0:
                px[nx, ny] = lerp(px[nx, ny][:3], color[:3], 0.55) + (255,)


# ------------------------------------------------------------------ sword
def eclipse_blade():
    img = new()
    px = img.load()
    ox, oy = 2.0, 30.0
    r2 = math.sqrt(2.0)
    for y in range(S):
        for x in range(S):
            dx, dy = x + 0.5 - ox, y + 0.5 - oy
            u = (dx - dy) / r2   # along the blade
            v = (dx + dy) / r2   # across the blade
            av = abs(v)
            c = None
            if 0 <= u < 3.2 and av <= 2.3 - u * 0.15:                     # pommel
                c = ramp(GOLD, 0.35 + 0.5 * (1 - av / 2.4))
            elif 3.2 <= u < 9.5 and av <= 1.35:                           # grip
                stripe = int(u * 1.3) % 2
                c = ramp(WOOD, 0.25 + 0.45 * (1 - av / 1.4) + 0.2 * stripe)
            elif 9.5 <= u < 12.2 and av <= 6.2 - abs(u - 10.8) * 0.9:     # guard
                shade = 0.3 + 0.6 * (1 - av / 6.4) + (0.15 if u < 10.8 else 0)
                c = ramp(GOLD, shade)
            elif 12.2 <= u <= 38.5:                                        # blade
                if u < 32.0:
                    w = 3.5
                else:
                    w = 3.5 * max(0.0, (38.5 - u) / 6.5)
                if av <= w:
                    t = (u - 12.2) / 26.0
                    edge = av > w - 1.1
                    if edge:
                        c = ramp(RAMP, 0.72 + 0.25 * t)
                    elif av < 0.7:
                        c = ramp(RAMP, 0.82 + 0.15 * t)
                    elif v > 0:
                        c = ramp(RAMP, 0.42 + 0.25 * t)
                    else:
                        c = ramp(RAMP, 0.22 + 0.22 * t)
            if c:
                px[x, y] = c
    # eclipse gem in the guard
    for y in range(S):
        for x in range(S):
            dx, dy = x + 0.5 - ox, y + 0.5 - oy
            u = (dx - dy) / r2
            v = (dx + dy) / r2
            d = math.hypot(u - 10.8, v)
            if d < 1.6:
                px[x, y] = ramp(RAMP, 0.95 if d < 0.8 else 0.7)
    # glowing runes along the blade's centre line
    for u0 in (15.5, 19.5, 23.5, 27.5):
        x = int(round(ox + u0 / r2))
        y = int(round(oy - u0 / r2))
        if 0 <= x < S and 0 <= y < S:
            px[x, y] = (255, 255, 255, 255)
    img = add_outline(img)
    sparkle(img, 27, 4, (200, 250, 255, 255), 1)
    sparkle(img, 22, 11, (255, 255, 255, 255), 0)
    return img


# ------------------------------------------------------------------ pickaxe
def eclipse_pickaxe():
    img = new()
    px = img.load()
    ox, oy = 2.0, 30.0
    r2 = math.sqrt(2.0)
    for y in range(S):
        for x in range(S):
            dx, dy = x + 0.5 - ox, y + 0.5 - oy
            u = (dx - dy) / r2
            v = (dx + dy) / r2
            av = abs(v)
            c = None
            if 0 <= u <= 33 and av <= 1.35:                               # handle
                stripe = int(u * 1.2) % 2
                c = ramp(WOOD, 0.2 + 0.5 * (1 - av / 1.4) + 0.18 * stripe)
                if u < 2.4:
                    c = ramp(GOLD, 0.4 + 0.4 * (1 - av / 1.4))            # butt cap
            # head: curved band, u = 31 - 0.042 v^2
            if abs(v) <= 15.5:
                centre = 29.5 - 0.050 * v * v
                thick = 3.4 * (1 - abs(v) / 16.5) ** 0.55 + 0.5
                du = u - centre
                if abs(du) <= thick:
                    k = (du + thick) / (2 * thick)       # 0 inner .. 1 outer
                    base = 0.30 + 0.55 * k + 0.12 * (1 - abs(v) / 16.0)
                    if k > 0.82:
                        base = 0.92
                    c = ramp(RAMP, base)
            if c:
                px[x, y] = c
    # gold binding where head meets handle
    for y in range(S):
        for x in range(S):
            dx, dy = x + 0.5 - ox, y + 0.5 - oy
            u = (dx - dy) / r2
            v = (dx + dy) / r2
            if 26.0 <= u <= 28.2 and abs(v) <= 2.0:
                px[x, y] = ramp(GOLD, 0.55 + 0.4 * (1 - abs(v) / 2.0))
    img = add_outline(img)
    sparkle(img, 9, 3, (200, 250, 255, 255), 1)
    sparkle(img, 27, 22, (255, 255, 255, 255), 0)
    return img


# ------------------------------------------------------------------ ingot
def inside(poly, x, y):
    n, ok = len(poly), False
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi + 1e-9) + xi:
            ok = not ok
        j = i
    return ok


def eclipsium_ingot():
    img = new()
    px = img.load()
    front = [(5, 14), (25, 14), (25, 24), (5, 24)]
    right = [(25, 14), (31, 13), (31, 21), (25, 24)]
    top = [(5, 14), (25, 14), (31, 9), (11, 9)]
    for y in range(S):
        for x in range(S):
            fx, fy = x + 0.5, y + 0.5
            if inside(front, fx, fy):
                t = (fy - 14) / 10.0
                px[x, y] = ramp(RAMP, 0.48 - 0.22 * t + 0.10 * (1 - (fx - 5) / 20.0))
            elif inside(right, fx, fy):
                t = (fy - 9) / 15.0
                px[x, y] = ramp(RAMP, 0.26 - 0.1 * t)
            elif inside(top, fx, fy):
                t = (fx - 5) / 26.0
                px[x, y] = ramp(RAMP, 0.66 + 0.2 * (1 - t))
    # bevel highlights
    for x in range(6, 25):
        if px[x, 14][3]:
            px[x, 14] = ramp(RAMP, 0.9)
    for y in range(15, 24):
        if px[5, y][3]:
            px[5, y] = ramp(RAMP, 0.72)
    # eclipse emblem on the front face
    cx, cy = 15.0, 19.0
    for y in range(S):
        for x in range(S):
            d = math.hypot(x + 0.5 - cx, y + 0.5 - cy)
            if px[x, y][3] and inside(front, x + 0.5, y + 0.5):
                if d < 2.6:
                    px[x, y] = ramp(RAMP, 0.02)
                elif d < 3.6:
                    px[x, y] = ramp(RAMP, 0.95 - (d - 2.6) * 0.3)
    img = add_outline(img)
    sparkle(img, 22, 11, (255, 255, 255, 255), 1)
    sparkle(img, 9, 21, (180, 245, 255, 255), 0)
    return img


# ------------------------------------------------------------------ rock helpers
BLOBS_RAW = [(11, 20, 8), (21, 21, 7), (16, 13, 7), (8, 13, 4.5), (24, 13, 4.5), (16, 24, 6)]


def blob_height(blobs, x, y):
    h = 0.0
    for bx, by, r in blobs:
        d2 = (x - bx) ** 2 + (y - by) ** 2
        if d2 < r * r:
            h = max(h, math.sqrt(r * r - d2) / r)
    return h


def shade_blobs(blobs, x, y, rng):
    e = 0.6
    h = blob_height(blobs, x, y)
    if h <= 0:
        return None
    hx = blob_height(blobs, x + e, y) - blob_height(blobs, x - e, y)
    hy = blob_height(blobs, x, y + e) - blob_height(blobs, x, y - e)
    light = -0.55 * hx - 0.8 * hy          # light from the upper left
    t = 0.38 + 0.55 * h * 0.5 + 0.9 * light + rng.uniform(-0.06, 0.06)
    return t


def raw_eclipsium():
    rng = random.Random(7)
    img = new()
    px = img.load()
    for y in range(S):
        for x in range(S):
            t = shade_blobs(BLOBS_RAW, x + 0.5, y + 0.5, rng)
            if t is not None:
                px[x, y] = ramp(RAMP, t * 0.85)
    for (x, y) in ((10, 17), (20, 19), (15, 11), (23, 12), (14, 22), (8, 12)):
        px[x, y] = ramp(RAMP, 0.93)
        px[x + 1, y] = ramp(RAMP, 0.72)
    img = add_outline(img)
    sparkle(img, 10, 17, (255, 255, 255, 255), 1)
    sparkle(img, 20, 19, (200, 250, 255, 255), 1)
    return img


# ------------------------------------------------------------------ blocks
def eclipsium_ore():
    rng = random.Random(21)
    img = Image.new("RGBA", (S, S), (0, 0, 0, 255))
    px = img.load()
    base = [(46, 46, 54), (58, 58, 68), (36, 36, 44), (66, 66, 78)]
    for y in range(S):
        for x in range(S):
            c = rng.choice(base)
            if (x // 4 + y // 4) % 2 == 0:
                c = lerp(c, (30, 30, 38), 0.25)
            px[x, y] = c + (255,)
    for _ in range(26):                      # cracks
        x, y = rng.randrange(S), rng.randrange(S)
        for _ in range(rng.randint(2, 5)):
            px[x % S, y % S] = (24, 24, 30, 255)
            x += rng.choice((-1, 0, 1))
            y += rng.choice((0, 1))
    clumps = [(8, 8, 5.0), (22, 10, 4.2), (14, 21, 5.5), (26, 25, 3.8), (5, 26, 3.2), (27, 3, 2.6)]
    for y in range(S):
        for x in range(S):
            t = shade_blobs(clumps, x + 0.5, y + 0.5, rng)
            if t is not None:
                px[x, y] = ramp(RAMP, t * 0.9)
    for (x, y) in ((7, 7), (21, 9), (13, 20), (25, 24), (4, 25)):
        px[x, y] = (255, 255, 255, 255)
        px[x + 1, y] = ramp(RAMP, 0.95)
        px[x, y + 1] = ramp(RAMP, 0.85)
    return img


def eclipsium_block():
    rng = random.Random(3)
    img = Image.new("RGBA", (S, S), (0, 0, 0, 255))
    px = img.load()
    for y in range(S):
        for x in range(S):
            gx, gy = x % 16, y % 16
            t = 0.36 + 0.06 * rng.random() + 0.12 * (1 - (gx + gy) / 30.0)
            if gx in (0, 1) or gy in (0, 1):
                t = 0.78 if min(gx, gy) < 2 and (gx <= 1 or gy <= 1) else t
            if gx in (14, 15) or gy in (14, 15):
                t = 0.10
            px[x, y] = ramp(RAMP, t)
    # rivets
    for (rx, ry) in ((3, 3), (12, 3), (3, 12), (12, 12), (19, 3), (28, 3), (19, 12), (28, 12),
                     (3, 19), (12, 19), (3, 28), (12, 28), (19, 19), (28, 19), (19, 28), (28, 28)):
        px[rx, ry] = ramp(RAMP, 0.95)
        px[rx + 1, ry + 1] = ramp(RAMP, 0.12)
    # central eclipse: dark disc with a glowing corona
    cx, cy = 16.0, 16.0
    for y in range(S):
        for x in range(S):
            d = math.hypot(x + 0.5 - cx, y + 0.5 - cy)
            if d < 5.4:
                px[x, y] = ramp(RAMP, 0.0)
            elif d < 6.8:
                px[x, y] = ramp(RAMP, 1.0 - (d - 5.4) * 0.35)
            elif d < 9.5:
                old = px[x, y][:3]
                px[x, y] = lerp(old, RAMP[4], 0.42 * (1 - (d - 6.8) / 2.7)) + (255,)
    return img


def preview(images, path):
    scale = 8
    pad = 6
    w = pad + len(images) * (S * scale + pad)
    sheet = Image.new("RGBA", (w, S * scale + 2 * pad), (58, 66, 84, 255))
    for i, im in enumerate(images):
        big = im.resize((S * scale, S * scale), Image.NEAREST)
        sheet.alpha_composite(big, (pad + i * (S * scale + pad), pad))
    sheet.save(path)


if __name__ == "__main__":
    items = {
        "eclipse_blade": eclipse_blade(),
        "eclipse_pickaxe": eclipse_pickaxe(),
        "eclipsium_ingot": eclipsium_ingot(),
        "raw_eclipsium": raw_eclipsium(),
    }
    blocks = {"eclipsium_ore": eclipsium_ore(), "eclipsium_block": eclipsium_block()}
    for n, im in items.items():
        im.save(os.path.join(ITEM_DIR, n + ".png"))
    for n, im in blocks.items():
        im.save(os.path.join(BLOCK_DIR, n + ".png"))
    out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(ROOT, "tools", "preview.png")
    preview(list(items.values()) + list(blocks.values()), out)
    print("textures written; preview:", out)
