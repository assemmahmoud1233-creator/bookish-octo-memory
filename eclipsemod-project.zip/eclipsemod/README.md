# Eclipse Arsenal — Forge 1.20.1 (بدون أي مودات تانية)

## الإضافات
- **Eclipse Blade (نصل الكسوف)**: ضرر 9، الضربة تدّي Wither II + Glowing وتسرق حياة،
  وكليك يمين = اندفاعة (Dash) تضرر كل اللي حواليك (تبريد 4 ثواني).
- **Eclipse Pickaxe (بيكاكس الكسوف)**: مستوى الدايموند، كل بلوك تكسره يدّيك Haste II.
- **Eclipsium Ore / Raw / Ingot / Block**: خام بيتولّد في الأوفرورلد (Y من -64 لـ 16)،
  بيدّي Fortune وSilk Touch، والوصفات (سملتنج/بلاست فرنس/كرافتنج) كلها جاهزة.
- لغات: English + العربية.

## بناء ملف الـ jar
الأمر بيحتاج Java 17 وإنترنت:

    ./gradlew build        # على ويندوز: gradlew.bat build

الملف بيطلع في: `build/libs/eclipsemod-forge-1.20.1-1.0.0.jar`
حطّه في فولدر `mods` عند Minecraft Forge 1.20.1 (47.x).

### بدون Java على جهازك (من الموبايل مثلًا)
ارفع المشروع على GitHub كـ repository جديد؛ الـ workflow الموجود في
`.github/workflows/build.yml` بيبني الـ jar تلقائيًا، وتنزّله من تاب **Actions**
(Artifacts → eclipsemod-jar).

## إعادة توليد التكستشرات والـ JSON (اختياري)
    pip install pillow
    python3 tools/gen_textures.py .
    python3 tools/gen_resources.py .
