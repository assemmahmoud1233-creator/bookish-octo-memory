package com.eclipsemod;

import com.eclipsemod.registry.ModBlocks;
import com.eclipsemod.registry.ModItems;
import com.eclipsemod.registry.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(EclipseMod.MODID)
public class EclipseMod {
    public static final String MODID = "eclipsemod";

    public EclipseMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModTabs.TABS.register(bus);
    }
}
