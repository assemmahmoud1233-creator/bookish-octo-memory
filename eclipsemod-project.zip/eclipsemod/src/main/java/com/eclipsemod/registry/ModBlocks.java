package com.eclipsemod.registry;

import com.eclipsemod.EclipseMod;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, EclipseMod.MODID);

    public static final RegistryObject<Block> ECLIPSIUM_ORE = BLOCKS.register("eclipsium_ore",
            () -> new DropExperienceBlock(
                    BlockBehaviour.Properties.copy(Blocks.DEEPSLATE_DIAMOND_ORE)
                            .strength(5.0F, 6.0F)
                            .lightLevel(state -> 6)
                            .requiresCorrectToolForDrops(),
                    UniformInt.of(4, 8)));

    public static final RegistryObject<Block> ECLIPSIUM_BLOCK = BLOCKS.register("eclipsium_block",
            () -> new Block(
                    BlockBehaviour.Properties.copy(Blocks.NETHERITE_BLOCK)
                            .lightLevel(state -> 9)));
}
