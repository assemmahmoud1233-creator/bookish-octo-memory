package com.eclipsemod.registry;

import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.common.ForgeTier;

public class ModTiers {
    /** Level 3 (diamond-class mining), very high durability, speed and damage. */
    public static final Tier ECLIPSIUM = new ForgeTier(
            3,              // mining level
            3200,           // durability
            11.0F,          // mining speed
            5.0F,           // attack damage bonus
            22,             // enchantability
            BlockTags.NEEDS_DIAMOND_TOOL,
            () -> Ingredient.of(ModItems.ECLIPSIUM_INGOT.get()));
}
