package com.eclipsemod.registry;

import com.eclipsemod.EclipseMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EclipseMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.eclipsemod"))
                    .icon(() -> new ItemStack(ModItems.ECLIPSE_BLADE.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.ECLIPSE_BLADE.get());
                        output.accept(ModItems.ECLIPSE_PICKAXE.get());
                        output.accept(ModItems.ECLIPSIUM_INGOT.get());
                        output.accept(ModItems.RAW_ECLIPSIUM.get());
                        output.accept(ModItems.ECLIPSIUM_ORE_ITEM.get());
                        output.accept(ModItems.ECLIPSIUM_BLOCK_ITEM.get());
                    })
                    .build());
}
