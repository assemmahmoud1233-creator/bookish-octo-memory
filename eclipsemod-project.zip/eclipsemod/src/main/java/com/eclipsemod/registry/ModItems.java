package com.eclipsemod.registry;

import com.eclipsemod.EclipseMod;
import com.eclipsemod.item.EclipseBladeItem;
import com.eclipsemod.item.EclipsePickaxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, EclipseMod.MODID);

    public static final RegistryObject<Item> RAW_ECLIPSIUM = ITEMS.register("raw_eclipsium",
            () -> new Item(new Item.Properties().rarity(Rarity.RARE)));

    public static final RegistryObject<Item> ECLIPSIUM_INGOT = ITEMS.register("eclipsium_ingot",
            () -> new Item(new Item.Properties().rarity(Rarity.EPIC).fireResistant()));

    public static final RegistryObject<Item> ECLIPSE_BLADE = ITEMS.register("eclipse_blade",
            () -> new EclipseBladeItem(ModTiers.ECLIPSIUM, 3, -2.4F,
                    new Item.Properties().rarity(Rarity.EPIC).fireResistant()));

    public static final RegistryObject<Item> ECLIPSE_PICKAXE = ITEMS.register("eclipse_pickaxe",
            () -> new EclipsePickaxeItem(ModTiers.ECLIPSIUM, 1, -2.8F,
                    new Item.Properties().rarity(Rarity.EPIC).fireResistant()));

    public static final RegistryObject<Item> ECLIPSIUM_ORE_ITEM = ITEMS.register("eclipsium_ore",
            () -> new BlockItem(ModBlocks.ECLIPSIUM_ORE.get(), new Item.Properties().rarity(Rarity.RARE)));

    public static final RegistryObject<Item> ECLIPSIUM_BLOCK_ITEM = ITEMS.register("eclipsium_block",
            () -> new BlockItem(ModBlocks.ECLIPSIUM_BLOCK.get(), new Item.Properties().rarity(Rarity.EPIC).fireResistant()));
}
