package com.eclipsemod.item;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Eclipse Blade
 *  - Hit: Wither II + Glowing on the target, soul-fire burst, heals the wielder a little.
 *  - Right click: "Eclipse Dash" - lunge forward, damage everything near you (4s cooldown).
 */
public class EclipseBladeItem extends SwordItem {
    private static final int DASH_COOLDOWN_TICKS = 80;

    public EclipseBladeItem(Tier tier, int attackDamage, float attackSpeed, Properties properties) {
        super(tier, attackDamage, attackSpeed, properties);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 1));
        target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0));
        attacker.heal(1.0F);

        if (target.level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                    target.getX(), target.getY(0.5D), target.getZ(),
                    24, 0.3D, 0.5D, 0.3D, 0.06D);
            server.sendParticles(ParticleTypes.REVERSE_PORTAL,
                    target.getX(), target.getY(0.5D), target.getZ(),
                    16, 0.4D, 0.6D, 0.4D, 0.1D);
        }
        return super.hurtEnemy(stack, target, attacker);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }

        Vec3 look = player.getLookAngle();
        player.setDeltaMovement(look.x * 1.8D, Math.max(look.y * 1.2D, 0.2D), look.z * 1.8D);
        player.hurtMarked = true;
        player.fallDistance = 0.0F;

        if (!level.isClientSide && level instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                    player.getX(), player.getY(0.5D), player.getZ(),
                    40, 0.5D, 0.6D, 0.5D, 0.08D);
            server.sendParticles(ParticleTypes.END_ROD,
                    player.getX(), player.getY(0.5D), player.getZ(),
                    25, 0.4D, 0.5D, 0.4D, 0.12D);
            level.playSound(null, player.blockPosition(),
                    SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 0.7F);

            AABB area = player.getBoundingBox().inflate(3.5D);
            for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, area,
                    e -> e != player && e.isAlive())) {
                entity.hurt(level.damageSources().playerAttack(player), 6.0F);
            }
            stack.hurtAndBreak(2, player, p -> p.broadcastBreakEvent(hand));
        }

        player.getCooldowns().addCooldown(this, DASH_COOLDOWN_TICKS);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.eclipsemod.blade.hit").withStyle(ChatFormatting.DARK_PURPLE));
        tooltip.add(Component.translatable("tooltip.eclipsemod.blade.use").withStyle(ChatFormatting.AQUA));
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
